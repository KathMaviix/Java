package xadrez;

public class Bispo extends Peca{
    @Override
    public void mover(){
        System.out.println("Andar na Diagonal");
    }


}
