package xadrez;

public class Cavalo extends Peca {
    @Override
    public void mover(){
        System.out.println("Andar em L");
    }


}
