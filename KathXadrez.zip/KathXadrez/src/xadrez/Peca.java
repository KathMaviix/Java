package xadrez;

public abstract class Peca {
    public abstract void mover();

}
