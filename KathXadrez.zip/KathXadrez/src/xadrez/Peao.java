package xadrez;

public class Peao extends Peca {
    @Override
    public void mover(){
        System.out.println("Andar pra frente");
    }

}
